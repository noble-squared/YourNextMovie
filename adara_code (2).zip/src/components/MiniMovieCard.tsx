import type React from 'react';
import { genreNumbers } from '../../shared/movieGenres';

interface MiniMovieCardProps {
  movieName: string;
  movieYear: string;
  movieGenres: number[];
}

const MiniMovieCard: React.FC<MiniMovieCardProps> = ({ movieName, movieYear, movieGenres }) => {
    return (
        <div className="mini-movie-card">
            <p>{movieName} ({movieYear})</p>
            <p>{movieGenres.map((id) => genreNumbers.get(id)).join(', ')}</p>
        </div>
    )
}

export default MiniMovieCard;