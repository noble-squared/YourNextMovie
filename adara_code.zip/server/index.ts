import { Hono } from 'hono'
import 'dotenv/config';
import { serve } from '@hono/node-server'
import { users } from './users.ts';
import type { User } from '../shared/user.ts';

//https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status#client_error_responses

let currentUser : User | null = null;
const app = new Hono();

const apiKey = process.env.TMDB_API_KEY;

app.get('/', (c) => {
  return c.json({
    ok: true,
    message: 'Hello Hono!',
  })
})


app.get('/users', (c) => {
  return c.json(users);
});


app.post('/login', async (c) => {
  const { username, password } = await c.req.json();

  for(const user of users) {
    if(user.username === username) {
      if(user.password === password) {
        currentUser = user;
        return c.json({ success: true });
      } else {
        return c.json({ success: false, error: 'Invalid username or password' }, 401);
      }
    }
  }

  return c.json({ success: false, error: 'Invalid username or password' }, 401);
});


app.post('/signup', async (c) => {
  const { id, name, username, password } = await c.req.json();

  for(const user of users) {
    if(user.username === username) {
      return c.json({ success: false, error: 'Username already taken' }, 400);
    }
  }

  users.push({ id, name, username, password, watchedMovies: [] });

  return c.json({ success: true });
});


//I dunno whether I actually want this to be an option lol
const resetPasswordCode : string | null = "I am not a bot"; //this is literally so insecure lmfao
//const resetPasswordCode : string | null = null; 
app.get('/reset-code', async (c) => {
  if(!resetPasswordCode) {
    return c.json({ success: false, error: "Not currently allowing password resets" });
  } else { 
    return c.json({ success: true, code: resetPasswordCode});
  }
});
app.post('/reset-password', async (c) => {
  const { username, newPassword, code } = await c.req.json();
  if(!code || code !== resetPasswordCode) {
    return c.json({ success: false, error: 'Please type the reset validation code exactly as listed' }, 401);
  }
  
  const user = users.find(user => user.username === username);
  if(user) {
    user.password = newPassword;
  }
});


app.post('/logout', (c) => {
  currentUser = null;
  return c.json({ success: true });
});


app.get('/userdata', (c) => {
  if(!currentUser) {
    return c.json({ 
      success: false,
      error: 'Not logged in'}, 401);
  } else {
    return c.json({
      success: true,
      user: currentUser
    });
  }
});

app.post('/api/get-filtered-movies', async (c) => {
  const { filter } = await c.req.json();
})

app.get('/api/test', (c) => {
  return c.json({ key: process.env.TMDB_API_KEY });
});


serve({
  fetch: app.fetch,
  port: 3000
}, (info) => {
  console.log(`Server is running on http://localhost:${info.port}`)
})