export interface User {
    id: number;
    name: string;
    username: string;
    password: string;
    watchedMovies: Movie[]; // Array of movie IDs that the user has watched, and whether they liekd them or not
}

export interface Movie {
    id: number;
    liked: boolean;
}