import React, { useState } from 'react';


const MoviesPage: React.FC = () => {
    const [movies, setMovies] = useState(null);
    const onSearch = async () => {
        try {
            const res = await fetch('/api/test');

            const testData = await res.json();
            setMovies(testData);
        } catch (error: unknown) {
            if (error instanceof Error) {
                console.error(error.message);
            } else {
                console.error("I dunno dawg")
            }
    }
    }

    return (
        <>
            { movies ? (
                <>
                    <h1>Movies</h1>
                </>
            ) : (
                <>
                    <h1>Search</h1>
                    <button onClick={() => onSearch()}>
                        Search
                    </button>
                </>
            )}
        </>
    )
}

export default MoviesPage;